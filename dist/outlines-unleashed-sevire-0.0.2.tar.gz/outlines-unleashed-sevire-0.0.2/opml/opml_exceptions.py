class MalformedOutline(Exception):
    pass

class MalformedTagRegex(Exception):
    pass

